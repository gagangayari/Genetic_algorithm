#include<stdlib.h>
#include<stdio.h>
#include<string.h>


int decimal(char *arr){
    int base=1;
    int num=0;
    for (int i=3;i>=0;i--){
        num=num+((arr[i]-'0')*base);
        base=base*2;
    }

    return num;
}

int main(int argc,char *argv[]){
    /*
    char bin[]="";
    strcat(bin,argv[1]);
    // bin[1]=(char)argv[2];

    // bin[2]=(char)argv[3];
    // bin[3]=(char)argv[4];
    for(int i=3;i<argc;i++){
        strcat(bin,argv[i]);
    }

    int dec=decimal(bin);
    int a=1;
    // printf("char %s ",bin);
    printf("here %d ",dec);
    

    // printf("%c",a);
    */

   int x=1;
   printf("%d ",x<<32);
    return 0;
}
