 

def fun(N):
    sum=0
    for c in N:
        if( c!="?"):
            sum+=int(c)
            
    if(sum%3==0):
        for c in N:
            if(c=="?"):
                print("0",end="")
            else:
                print(c,end="")


    else:

        i=1
        s=""
        while(True):
            diff=3*i-sum
            if(diff>0):
                flag=0
                for k in reversed(N):
                    print("here",k,flag)
                    if(k=="?" and flag==0):
                        s=str(diff)+s
                        flag=1
                    elif(k=="?"):
                        s="0"+s
                    else:
                        s=k+s
                    print("str",s)
                print(s)
                break
            i+=1
#%%

def appendzeros(ss):
    l=len(ss)
    ss=("0"*(32-l))+ss
    # print(ss)
    for i in ss:
        print(i,end=",")


appendzeros("110011100011")
# fun("5?9?3?????")

# %%
len("100001111010000101011010")
# %%
