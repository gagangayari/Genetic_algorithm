#include<bits/stdc++.h>

#define key_size 167
int get_random_bit(int size){

}
struct chrom
{
    int key[key_size]=get_random_bit();
    int fitness= -1;
}chrom;


void flip_bits(){  //Flip bits at some location

}
void mutation(chrom sample){
    //Mutation in Constants
    //const1 k1-k32
    flip_bits(sample,0,31)
    flip_bits(sample,32,63);
    flip_bits(sample,64,95)
    flip_bits(sample,96,137);
    flip_bits(sample,138,169);

    //Mutation for remaining bits



}

void helper_xover_consts(){

}
void crossover(chrom mate1,chrom mate2){
    //for constants
    mate1.key[]
    

}

int main(){

}